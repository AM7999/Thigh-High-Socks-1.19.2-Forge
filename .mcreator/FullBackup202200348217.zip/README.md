# Thigh High Socks Mod For 1.19.2
A Joke mod for Minecraft Java partially made using MCreator
This mod took an embarasingly long time to make (and as of writing this on 1/17/23 its still not finished)

# Compiling

1. Clone this repository
2. Install Java 11. Installing Gradle is optional
3. Run Gradle or the `gradlew` script

On Windows
`.\gradlew.bat build`

On Linux
`sh gradlew build`
or `gradle build`
